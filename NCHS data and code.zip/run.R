
# Load the data
dat <- NULL;
for (m in 43:52)
{
tmp <- read.csv(paste("NCHSData",m,".csv",sep=""));
tmp$Update = m;
dat <- rbind(dat,tmp)
}

dat$Update <- factor(dat$Update);
dat$Year <- factor(dat$Year);
# Be lazy and just plot
library(ggplot2);

for (m in 43:52){
p<- ggplot(dat[dat$Year!=2020 & dat$Update==m,],aes(x=Week,y=All.Deaths,colour=Year))+geom_point()+ylim(10000,80000);
p<- p+geom_point(data = dat[dat$Year==2020 & dat$Update==m,],color="black")
ggsave(file=paste(m,".png",sep=""),p, width = 6, height = 4);

} 

tmp <- dat[!(dat$Year==2020 & dat$Week >45),]
for (m in 43:52){
  p<- ggplot(tmp[tmp$Year!=2020 & tmp$Update==m,],aes(x=Week,y=All.Deaths,colour=Year))+geom_point()+ylim(10000,80000);
  p<- p+geom_point(data = tmp[tmp$Year==2020 & tmp$Update==m,],color="black")
  ggsave(file=paste("a",m,".png",sep=""),p, width = 6, height = 4);
  
}  